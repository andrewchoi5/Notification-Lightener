	function roundNum (numb, places){

		return +numb.toFixed(places);
	 
	}
	
	function newerButtonCheck (monthButtonVal, yearButtonVal){
	
		var d = new Date();
		if (monthButtonVal >= d.getMonth() && yearButtonVal >= d.getFullYear()){
			
			$( "#olderButton" ).removeClass().addClass('next');
			$( "#newerButton" ).removeClass().addClass('next disabled');
			$('#newerRef').unbind();
			console.log("Attempting to disable");
			
		}
		else {
			
			$( "#olderButton" ).removeClass().addClass('next');
			$( "#newerButton" ).removeClass().addClass('next');
			
			$('#olderRef').click( function() {

				var newTempMonth = parseInt($('input#hiddenMonth').val(), 10);
				console.log("What's the newOlder month? " + newTempMonth);
				var newMonth;
				var newYear;
				
				//handle Jan to Dec change
				if (newTempMonth == 0){
					newMonth = 11;
					newYear = currentYear - 1;
				}
				else {
					newMonth = newTempMonth - 1;
					newYear = currentYear;
				}
				
				buildPageData(newMonth, newYear); 
				
				$('input#hiddenMonth').val(newMonth);
				$('input#hiddenYear').val(newYear);
				
				return false; 
				
			} );
			
			$('#newerRef').click( function() { 

				var newTempMonth = parseInt($('input#hiddenMonth').val(), 10);
				console.log("What's the newNewer month? " + newTempMonth);
				var newMonth;
				var newYear;
				
				//handle Jan to Dec change
				if (newTempMonth == 11){
					newMonth = 0;
					newYear = currentYear + 1;
				}
				else {
					newMonth = newTempMonth + 1;
					newYear = currentYear;
				}
				
				buildPageData(newMonth, newYear); 
				
				$('input#hiddenMonth').val(newMonth);
				$('input#hiddenYear').val(newYear);
				
				return false;
				
			} );
			console.log("Attempting to enable");
		}
	}
	
	function minutesInMonth(startDate, endDate){

		var seconds = Math.floor((endDate - (startDate))/1000);
		var minutes = Math.floor(seconds/60);
		var hours = Math.floor(minutes/60);
		var days = Math.floor(hours/24);

		//hours = hours-(days*24);
		//minutes = minutes-(days*24*60)-(hours*60);
		//seconds = seconds-(days*24*60*60)-(hours*60*60)-(minutes*60);

		// console.log("startDate: " + startDate);
		// console.log("endDate: " + endDate);
		// console.log("# seconds in month: " + seconds);
		// console.log("# hours in month: " + hours);
		// console.log("# minutes in month: " + minutes);
		
		return minutes;
		
	}

	function buildPageData (monthVal, yearVal){
	
		$( "#olderButton" ).removeClass().addClass('next disabled');
		$( "#newerButton" ).removeClass().addClass('next disabled');
	
		//clear the table before we build it in case it contains a previous month
		$('#resultTable > thead').empty();
		$('#resultTable > tbody').empty();
		
		//clear the date first
		$( "#monthYearLabel" ).empty();
	
		//start the spinner
		var opts = {
            lines: 16, // The number of lines to draw
            length: 5, // The length of each line
            width: 3, // The line thickness
            radius: 10, // The radius of the inner circle
            corners: 1, // Corner roundness (0..1)
            rotate: 0, // The rotation offset
            color: '#FFF', // #rgb or #rrggbb
            speed: 1, // Rounds per second
            trail: 60, // Afterglow percentage
            shadow: false, // Whether to render a shadow
            hwaccel: false, // Whether to use hardware acceleration
            className: 'spinner', // The CSS class to assign to the spinner
            zIndex: 2e9, // The z-index (defaults to 2000000000)
            top: 25, // Top position relative to parent in px
            left: 25 // Left position relative to parent in px
        };
        var target = document.getElementById('spinthingy');
        var spinner = new Spinner(opts).spin(target);
		
		//check if we need to enable or disable the "newer" button
		
		//setup the monthly stuff

		var monthNames = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
		
		//set the title
		//var d = new Date();
		var todayTitle = monthNames[monthVal] + " " + yearVal;
		
		////////build URL string
		
		//get hostname for server
		var dHostname = window.location.hostname;
		console.log("Host check: " + dHostname);
		
		//get first and last day of requested month
		var dFirst = new Date(yearVal, monthVal, 1);
		var dLast = new Date(yearVal, monthVal + 1, 0);
		var finalFirstDate = dFirst.getFullYear() + '-' + ('0' +(dFirst.getMonth()+1)).slice(-2) + '-' + ('0' + dFirst.getDate()).slice(-2);
		var finalLastDate = dLast.getFullYear() + '-' + ('0' + (dLast.getMonth()+1)).slice(-2) + '-' + ('0' + dLast.getDate()).slice(-2);
		
		//var jsonResourceURL = "http://ciokmp001cnc:8080/bbar/public/calculate.py?from=" + finalFirstDate + "&to=" + finalLastDate + "&services%5B%5D=BBM_FULL_ALASKA&services%5B%5D=BBM_FULL_BB10&services%5B%5D=BBM_FULL_BBOS&reports%5B%5D=combined-total-subscriber-minutes&format=HTML&go=Go%21";
		var jsonResourceURL = "http://" + dHostname + "/greenstate/performance/?from=" + finalFirstDate + "&to=" + finalLastDate + "&excludeS4=1&includeInternal=0&excludeCRQ=1&format=json";

		// console.log("dFirst: " + dFirst);
		// console.log("dLast: " + dLast);
		// console.log("finalFirstDate: " + finalFirstDate);
		// console.log("finalLastDate: " + finalLastDate);
		// console.log("jsonResourceURL URL: " + jsonResourceURL);
		
		var availMinutes = minutesInMonth(dFirst,dLast);
		
		//load files and setup monitoring of process

		var data = $.getJSON( jsonResourceURL, function() {
		  console.log( "success" );
		})
		  .done(function() {
			console.log( "second success" );
		  })
		  .fail(function() {
			console.log( "error" );
		  })
		  .always(function() {
			console.log( "complete" );
		  });
		  
		// Perform other work here ...
		 
		// Set another completion function for the request above
		data.complete(function() {

			function merge_data(obj1,obj2){
				var obj3 = {};
				var dupes = [];
				
				for (var attrname1 in obj1) { 
					for (var attrname2 in obj2) {
						//console.log("obj1: " + attrname1 + " & obj2: " + attrname2);
						if (attrname1 == attrname2){
							//console.log(attrname1 + " gmps: " + obj1[attrname1].totals.gmps);
							//console.log(attrname2 + " gmps: " + obj2[attrname2].gmps);
							obj1[attrname1].totals.gmps += obj2[attrname2].totals.gmps;
							obj1[attrname1].totals.ntickets += obj2[attrname2].totals.ntickets;
							//console.log("1st JSON - " + attrname1 + " gmps: " + obj1[attrname1].gmps + " & ntickets: " + obj1[attrname1].ntickets);
							obj3[attrname1] = obj1[attrname1];
							dupes[dupes.length] = attrname1;
							//console.log("Object name: " + attrname1 + " - Modified object: " + JSON.stringify(obj3[attrname1]));
							//console.log("Print dupes list: " + JSON.stringify(dupes));
						}
						else {
							obj3[attrname1] = obj1[attrname1]; 
						}
					}
				}
				for (var attrname2 in obj2) { 
					for (var attrname1 in obj1) {
						//console.log("obj2: " + attrname2 + " & obj1: " + attrname1);
						if (attrname2 != attrname1){
							//console.log("2nd JSON Compare - 1st JSON - " + attrname1 + " 2nd JSON - " + attrname2)
							//console.log("2nd JSON - " + attrname2 + " gmps: " + obj2[attrname2].gmps);
							if ($.inArray(attrname2, dupes) == -1){
								obj3[attrname2] = obj2[attrname2]; 
							}
							//console.log("Object name: " + attrname2 + " - Modified object: " + JSON.stringify(obj3[attrname2]));;
						}
					}
				}
				return obj3;
			}

			console.log(data);
			var combinedBBMServices = data.responseJSON["services"]["BBM"]["resources"];
			var combinedEntServices = data.responseJSON["services"]["Enterprise"]["resources"];
			var combinedHHServices = data.responseJSON["services"]["Device"]["resources"];

			//console.log(data.responseJSON["Total Combined Service GMpS by Resource"]["resource-totals"]["Combined Services"]);

			var merged1 = merge_data(combinedBBMServices,combinedEntServices);
			
			//console.log("Let's see if we can merge once: " + JSON.stringify(merged1));
			
			var merged2 = merge_data(merged1,combinedHHServices);
			
			//console.log("Let's see if we can merge twice: " + JSON.stringify(merged2));
			
			
			//set the newer button state
			newerButtonCheck(monthVal, yearVal);
				
			//stop the spinner
			
			spinner.stop();
			
			//build table header when data is retrieved
			var newHead = '<tr><th>Resource Group</th><th class="text-center">GMpS</th><th class="text-center">Availability</th><th class="text-center">Tickets</th></tr>';
			$('#resultTable > thead:last').append(newHead);
			
			//build date when data is retrieved
			$( "#monthYearLabel" ).html( todayTitle );
			
			for (var sesService in merged2)
			{
				//console.log(combinedBBMServices[sesService]);
				var serviceName = sesService;
				var newGMPS = merged2[sesService].totals.gmps
				var newNTickets = merged2[sesService].totals.ntickets
				
				var availValue = roundNum((1-(newGMPS/availMinutes))*100, 3);
				
				var newRow = '<tr><td>' + serviceName + '</td><td class="text-center">' + roundNum(newGMPS,2) + '</td><td class="text-center">' + availValue + '%</td><td class="text-center"><span class="badge">' + newNTickets + '</span></td></tr>';
				
				$('#resultTable > tbody:last').append(newRow);
				
			}
		  
		});
	}
	
	//stuff that happens on loading the page
	var d = new Date();
	buildPageData(d.getMonth(), d.getFullYear());