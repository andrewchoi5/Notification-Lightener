	function roundNum (numb){

		return +numb.toFixed(2);
	 
	}
	
	function newerButtonCheck (monthButtonVal, yearButtonVal){
	
		var d = new Date();
		if (monthButtonVal >= d.getMonth()){
			$( "#newerButton" ).removeClass().addClass('next disabled');
		}
		else {
			$( "#newerButton" ).removeClass().addClass('next');
		}
	}

	function buildPageData (monthVal, yearVal){
		
		//check if we need to enable or disable the "newer" button
		
		//setup the monthly stuff

		var monthNames = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
		
		//set the title
		//var d = new Date();
		var todayTitle = monthNames[monthVal] + " " + yearVal;
		$( "#monthYearLabel" ).html( todayTitle );

		//set the newer button state
		newerButtonCheck(monthVal, yearVal);
		
		////////build URL string
		
		//get first and last day of requested month
		var dFirst = new Date(yearVal, monthVal, 1);
		var dLast = new Date(yearVal, monthVal + 1, 0);
		var finalFirstDate = dFirst.getFullYear() + '-' + ('0' +(dFirst.getMonth()+1)).slice(-2) + '-' + ('0' + dFirst.getDate()).slice(-2);
		var finalLastDate = dLast.getFullYear() + '-' + ('0' + (dLast.getMonth()+1)).slice(-2) + '-' + ('0' + dLast.getDate()).slice(-2);
		
		var bbmURL = "http://ciokmp001cnc:8080/bbar/public/calculate.py?from=" + finalFirstDate + "&to=" + finalLastDate + "&services%5B%5D=BBM_FULL_ALASKA&services%5B%5D=BBM_FULL_BB10&services%5B%5D=BBM_FULL_BBOS&reports%5B%5D=combined-total-subscriber-minutes&format=HTML&go=Go%21";
		var entURL = "http://ciokmp001cnc:8080/bbar/public/calculate.py?from=" + finalFirstDate + "&to=" + finalLastDate + "&services%5B%5D=ENTERPRISE_BB10&services%5B%5D=ENTERPRISE_BBOS&services%5B%5D=ENTERPRISE_CONTRAIL&reports%5B%5D=combined-total-subscriber-minutes&format=HTML&go=Go%21";
		var hhURL = "http://ciokmp001cnc:8080/bbar/public/calculate.py?from=" + finalFirstDate + "&to=" + finalLastDate + "&services%5B%5D=HANDHELD_BB10&services%5B%5D=HANDHELD_BBOS&services%5B%5D=HANDHELD_MULTI&reports%5B%5D=combined-total-subscriber-minutes&format=HTML&go=Go%21";
		
		console.log("dFirst: " + dFirst);
		console.log("dLast: " + dLast);
		console.log("finalFirstDate: " + finalFirstDate);
		console.log("finalLastDate: " + finalLastDate);
		console.log("BBM URL: " + bbmURL);
		console.log("Ent URL: " + entURL);
		console.log("HH URL: " + hhURL);
		
		//load files and setup monitoring of process

		var data = $.getJSON( "ses-bbm-json-unformatted.txt", function() {
		  console.log( "bbm success" );
		})
		  .done(function() {
			console.log( "bbm second success" );
		  })
		  .fail(function() {
			console.log( "bbm error" );
		  })
		  .always(function() {
			console.log( "bbm complete" );
		  });
		  
		var dataEnt = $.getJSON( "ses-ent-json-unformatted.txt", function() {
		  console.log( "ent success" );
		})
		  .done(function() {
			console.log( "ent second success" );
		  })
		  .fail(function() {
			console.log( "ent error" );
		  })
		  .always(function() {
			console.log( "ent complete" );
		  });		
		  
		var dataHH = $.getJSON( "ses-hh-json-unformatted.txt", function() {
		  console.log( "hh success" );
		})
		  .done(function() {
			console.log( "hh second success" );
		  })
		  .fail(function() {
			console.log( "hh error" );
		  })
		  .always(function() {
			console.log( "hh complete" );
		  });
		 
		// Perform other work here ...
		 
		// Set another completion function for the request above
		data.complete(function() {

			console.log(data);
			var combinedBBMServices = data.responseJSON["Total Combined Service GMpS by Resource"]["resource-totals"]["Combined Services"];

			console.log( "complete, now do enterprise" );
			//console.log(data.responseJSON["Total Combined Service GMpS by Resource"]["resource-totals"]["Combined Services"]);
		  
			dataEnt.complete(function() {
			
				console.log(dataEnt);
				var combinedEntServices = dataEnt.responseJSON["Total Combined Service GMpS by Resource"]["resource-totals"]["Combined Services"];
			
				console.log( "complete, now do HH" );
				//console.log(data.responseJSON["Total Combined Service GMpS by Resource"]["resource-totals"]["Combined Services"]);
			
				dataHH.complete(function() {
				
					function merge_data(obj1,obj2){
						var obj3 = {};
						var dupes = [];
						
						for (var attrname1 in obj1) { 
							for (var attrname2 in obj2) {
								//console.log("obj1: " + attrname1 + " & obj2: " + attrname2);
								if (attrname1 == attrname2){
									//console.log(attrname1 + " gmps: " + obj1[attrname1].gmps);
									//console.log(attrname2 + " gmps: " + obj2[attrname2].gmps);
									obj1[attrname1].gmps += obj2[attrname2].gmps;
									obj1[attrname1].ntickets += obj2[attrname2].ntickets;
									//console.log("1st JSON - " + attrname1 + " gmps: " + obj1[attrname1].gmps + " & ntickets: " + obj1[attrname1].ntickets);
									obj3[attrname1] = obj1[attrname1];
									dupes[dupes.length] = attrname1;
									//console.log("Object name: " + attrname1 + " - Modified object: " + JSON.stringify(obj3[attrname1]));
									//console.log("Print dupes list: " + JSON.stringify(dupes));
								}
								else {
									obj3[attrname1] = obj1[attrname1]; 
								}
							}
						}
						for (var attrname2 in obj2) { 
							for (var attrname1 in obj1) {
								//console.log("obj2: " + attrname2 + " & obj1: " + attrname1);
								if (attrname2 != attrname1){
									//console.log("2nd JSON Compare - 1st JSON - " + attrname1 + " 2nd JSON - " + attrname2)
									//console.log("2nd JSON - " + attrname2 + " gmps: " + obj2[attrname2].gmps);
									if ($.inArray(attrname2, dupes) == -1){
										obj3[attrname2] = obj2[attrname2]; 
									}
									//console.log("Object name: " + attrname2 + " - Modified object: " + JSON.stringify(obj3[attrname2]));;
								}
							}
						}
						return obj3;
					}
			
					console.log(dataHH);
					var combinedHHServices = dataHH.responseJSON["Total Combined Service GMpS by Resource"]["resource-totals"]["Combined Services"];
				
					console.log( "finally, all complete" );
					//console.log(data.responseJSON["Total Combined Service GMpS by Resource"]["resource-totals"]["Combined Services"]);

					var merged1 = merge_data(combinedBBMServices,combinedEntServices);
					
					console.log("Let's see if we can merge once: " + JSON.stringify(merged1));
					
					var merged2 = merge_data(merged1,combinedHHServices);
					
					console.log("Let's see if we can merge twice: " + JSON.stringify(merged2));
					
					//clear the table before we build it in case it contains a previous month
					$('#resultTable > tbody').empty();
					
					for (var sesService in merged2)
					{
						//console.log(combinedBBMServices[sesService]);
						var serviceName = sesService;
						var newGMPS = merged2[sesService].gmps
						var newNTickets = merged2[sesService].ntickets
						
						var newRow = '<tr><td>' + serviceName + '</td><td class="text-center">' + roundNum(newGMPS) + '</td><td class="text-center"></td><td class="text-center">' + newNTickets + '</td></tr>';
						
						$('#resultTable > tbody:last').append(newRow);
						
					}
				});
				
			});
		  
		});
	}
	
	var d = new Date();
	buildPageData(d.getMonth(), d.getFullYear());