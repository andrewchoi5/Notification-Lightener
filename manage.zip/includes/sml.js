
var sml = {};  //global variable of all sml data
function setJSON(json)
{
	sml = json;
	console.log(sml);
}

function showSearchSuggestions(search)
{
	var searchResults = document.getElementById('searchresults');
	var searchBox = document.getElementById('searchvalue');
		
	$(document).keyup(function(e) {
		if (e.keyCode == 27) // esc
		{ 
			searchResults.style.display = "none";
			searchBox.value = "";
		}   
	})
		
	var processResults = getProcessResults(search);
	var phaseResults = getPhaseResults(search);
	var deliverableResults = getDeliverableResults(search);
	var html = phaseResults + processResults + deliverableResults;
	
	if (search.length == 0 || html.length == 0)
		searchResults.style.display = "none";
	else	
		searchResults.style.display = "block";
			
	searchResults.innerHTML =  html;
}

function getDeliverableResults(search)
{
	var html = '';
	for (var index in sml.deliverables)
	{
		//if search matches a deliverable name
		var name = sml.deliverables[index].name;
		if (name.toLowerCase().indexOf(search.toLowerCase()) > -1)
			html += "<div class='searchResultDiv' onclick='window.location.href = \"./deliverable.html?d=" + sml.deliverables[index].id + "\"'>" + name + "</div>";
			
		//if search matches the owner of the deliverable
		//for (var owner in sml.processes[sml.deliverables[index].processid].owners)
			//if (owner.toLowerCase().indexOf(search.toLowerCase()) > -1)
				//html += "<div class='searchResultDiv' onclick='window.location.href = \"./deliverable.html?d=" + sml.deliverables[index].id + "\"'>" + name + "</div>";
	}

	if (html != "")
		return "<div class='searchResultHeader'>Deliverables</div>" + html;
	else
		return '';
}

function getPhaseResults(search)
{
	var html = '';
	for (var phaseID in sml.phases)
		if (sml.phases[phaseID].toLowerCase().indexOf(search.toLowerCase()) > -1)
			html += "<div class='searchResultDiv' onclick='window.location.href = \"./phase.html?phase=" + phaseID + "\"'>" + sml.phases[phaseID] + "</div>";

	if (html != "")
		return "<div class='searchResultHeader'>Phases</div>" + html;
	else
		return '';
}

function getProcessResults(search)
{
	var html = '';
	for (var processID in sml.processes)
	{
		//if search matches the process name
		if (sml.processes[processID].name.toLowerCase().indexOf(search.toLowerCase()) > -1)
			html += "<div class='searchResultDiv' onclick='window.location.href = \"./process.html?process=" + processID + "\"'>" + sml.processes[processID].name + "</div>";
			
		//if search matches the process owner name
		for (var owner in sml.processes[processID].owners)
			if (owner.toLowerCase().indexOf(search.toLowerCase()) > -1)
				html += "<div class='searchResultDiv' onclick='window.location.href = \"./process.html?process=" + processID + "\"'>" + sml.processes[processID].name + "</div>";
	}
		
	if (html != "")
		return "<div class='searchResultHeader'>Processes</div>" + html;
	else
		return '';
}

function drawDeliverableNavigator(json)
{
	var deliverableshtml = "<div class='table-responsive'>";
	deliverableshtml += "<table id='deliverabletable' class='table table-condensed' cellpadding='0' cellspacing='0' width='100%'>";
	deliverableshtml += "<thead>";
	
	//Draw in the Phases for columns
	deliverableshtml += "<tr><th></th>";
	for (var ph in json.phases)
		deliverableshtml += "<th id='phase" + ph + "' class='phaseHeader' title='" + json.phases[ph] + "' onclick='window.location.href = \"./phase.html?phase=" + ph + "\"'>" + json.phases[ph] + "</th>";

	deliverableshtml += "</tr>";
	deliverableshtml += "</thead>";
	deliverableshtml += "<tbody>";
	
	//Sort the Processes
	var sortedProcesses = [];
	for (var pr in json.processes)
		sortedProcesses.push(json.processes[pr].ordinal);
	sortedProcesses.sort(sortNumber);
	
	//Draw in the Processes
	for (var index in sortedProcesses)
	{
		var processID = getProcessID(json.processes, sortedProcesses[index]);
		
		//list owners
		var ownerlist = "";
		var ownersArray = [];
		for (var owner in json.processes[processID].owners)
			ownersArray.push(owner);
		ownersArray.sort();		
		if (ownersArray.length > 0)
		{
			ownerlist += "<ul id='owner" + processID + "' class='owner'>";
			for (var o in ownersArray)
			{
				ownerlist += "<li>" + ownersArray[o];
				if (json.processes[processID].owners[ownersArray[o]].length > 0)
					ownerlist += " [" + json.processes[processID].owners[ownersArray[o]] + "]";
				ownerlist += "</li>";
			}
			ownerlist += "</ul>";
		}
		
		deliverableshtml += "<tr><td id='process" + processID + "' class='processHeader' onmouseout='dehighlight(" + 0 + ", " + processID + ");' onmouseover='highlight(" + 0 + ", " + processID + ");' onclick='window.location.href = \"./process.html?process=" + processID + "\"'>" + json.processes[processID].name + ownerlist + "</td>";
		
		//LINKS to process/phase combos
		for (var phaseID in json.phases)
		{
			if (phaseID in json.processes[processID].phases)
			{
				var deliverableCount = json.processes[processID].phases[phaseID].length;
				deliverableshtml += "<td class='deliverableBox deliverableLink deliverableCount' onmouseout='dehighlight(" + phaseID + ", " + processID + ");' onmouseover='highlight(" + phaseID + ", " + processID + ");' onclick='window.location.href = \"./phaseprocess.html?phase=" + phaseID + "&process=" + processID + "\"'>" + deliverableCount + "</td>";
			}
			else
				deliverableshtml += "<td class='deliverableBox'></td>";
		}
		deliverableshtml += "</tr>";
	}
	deliverableshtml += "</tbody>";
	deliverableshtml += "</table>";
	deliverableshtml += '</div>';

	
	var deliverables = document.getElementById('deliverableNavigator');
	deliverables.innerHTML = deliverableshtml;	
}

function getProcessID(processes, ordinal)
{
	for (var pID in processes)
		if (ordinal == processes[pID].ordinal)
			return pID;
}

function sortNumber(a,b) 
{
   return a - b;
}

function drawPhaseProcess(phaseID, processID, json)
{
	var phaseName = document.getElementById('phaseName');
	phaseName.innerHTML = "Phase: " + json.phases[phaseID];
	
	var processName = document.getElementById('processName');
	processName.innerHTML = "Process: " + json.processes[processID].name;
	
	var ownersArray = [];
	for (var owner in json.processes[processID].owners)
	{
		var program = "";
		if (json.processes[processID].owners[owner].length > 0)
			program = " [" + json.processes[processID].owners[owner] + "]";
		ownersArray.push(owner + program);		
	}
	ownersArray.sort();	
	if (ownersArray.length > 0)
	{
		var label = "Owner";
		var processOwner = document.getElementById('processOwner');
		if (ownersArray.length > 1)
			label += "s";
		processOwner.innerHTML = label + ": " + ownersArray.join(", ");	
	}	

	var phaseprocess = document.getElementById('phaseprocess');
	phaseprocess.innerHTML = phaseprocess.innerHTML + "&nbsp;&nbsp;&nbsp;<span class='label label-default label-hover' id='deliverableProcess' onclick='window.location.href = \"./process.html?process=" + processID + "\"'>Process: " + json.processes[processID].name + "</span>";	
	phaseprocess.innerHTML = phaseprocess.innerHTML + " <span class='label label-primary label-hover' id='deliverablePhase' onclick='window.location.href = \"./phase.html?phase=" + phaseID + "\"'>Phase: " + json.phases[phaseID] + "</span>";
	
	var deliverableshtml = "<table cellpadding='0' cellspacing='0' width='100%'><tr><td><ol>";
	for (var deliverableID in json.processes[processID].phases[phaseID])
	{
		var deliverable = json.deliverables[json.processes[processID].phases[phaseID][deliverableID]];
		var description = '';
		if (deliverable.description) description = deliverable.description;			
	
		deliverableshtml += "<li>";
		deliverableshtml += "<a href='./deliverable.html?d=" + deliverable.id + "' title='" + description + "'>" + deliverable.name + "</a>";
		deliverableshtml += "</li>";
	}
	deliverableshtml += "</ol></td></tr></table>";

	var deliverables = document.getElementById('deliverables');
	deliverables.innerHTML = deliverableshtml;	
}

function drawProcess(id, json)
{
	var processName = document.getElementById('processName');
	processName.innerHTML = "Process: " + json.processes[id].name;
	
	var ownersArray = [];
	for (var owner in json.processes[id].owners)
	{
		var program = "";
		if (json.processes[id].owners[owner].length > 0)
			program = " [" + json.processes[id].owners[owner] + "]";
		ownersArray.push(owner + program);	
	}
	ownersArray.sort();	
	if (ownersArray.length > 0)
	{
		var label = "Owner";
		var processOwner = document.getElementById('processOwner');
		if (ownersArray.length > 1)
			label += "s";
		processOwner.innerHTML = label + ": " + ownersArray.join(", ");	
	}
	
	//draw in deliverables
	var deliverableshtml = "<table cellpadding='0' cellspacing='0' width='100%'>";
	deliverableshtml += "<tr><td class='processTitle'>Phase</td><td class='processTitle'>Deliverable</td><td>";
	for (var phaseID in json.phases)
	{
		deliverableshtml += "<tr><td class='processName'><span class='label label-primary label-hover' onclick='window.location.href = \"./phase.html?phase=" + phaseID + "\"'>" + json.phases[phaseID] + "</span></td><td class='deliverableList'>";
		
		//deliverables table
		deliverableshtml += "<table cellpadding='0' cellspacing='0' width='100%'><tr><td><ol>";			
		for (var deliverableID in json.processes[id].phases[phaseID])
		{
			var deliverable = json.deliverables[json.processes[id].phases[phaseID][deliverableID]];
			var description = '';
			if (deliverable.description) description = deliverable.description;
			
			deliverableshtml += "<li>";
			deliverableshtml += "<a href='./deliverable.html?d=" + deliverable.id + "' title='" + description + "'>" + deliverable.name + "</a>";
			deliverableshtml += "</li>";
		}
		deliverableshtml += "</ol></td></tr></table>";
		deliverableshtml += "</tr>"; //end of process
	}
	deliverableshtml += "</table>";
	
	var deliverables = document.getElementById('deliverables');
	deliverables.innerHTML = deliverableshtml;

}

function drawPhase(id, json)
{
	var phaseName = document.getElementById('phaseName');
	phaseName.innerHTML = "Phase: " + json.phases[id];	

	var deliverableshtml = "<table cellpadding='0' cellspacing='0' width='100%'>";
	deliverableshtml += "<tr><td class='processTitle'>Process</td><td class='processTitle'>Deliverable</td><td>";
	
	for (var processID in json.processes)
	{
		deliverableshtml += "<tr><td class='processName'><span class='label label-default label-hover' onclick='window.location.href = \"./process.html?process=" + processID + "\"'>" + json.processes[processID].name + "</span></td><td class='deliverableList'>";
		
		//deliverables table
		deliverableshtml += "<table cellpadding='0' cellspacing='0' width='100%'><tr><td><ol>";	
		for (var deliverableID in json.processes[processID].phases[id])
		{
			var deliverable = json.deliverables[json.processes[processID].phases[id][deliverableID]];
			var description = '';
			if (deliverable.description) description = deliverable.description;			
		
			deliverableshtml += "<li>";
			deliverableshtml += "<a href='./deliverable.html?d=" + deliverable.id + "' title='" + description + "'>" + deliverable.name + "</a>";
			//deliverableshtml += " <span class='label label-default' id='deliverableProcess'>Process: " + json.deliverables[deliverableID].process + "</span>";
			//deliverableshtml += " <span class='label label-primary' id='deliverablePhase'>Phase: " + json.deliverables[deliverableID].phase + "</span>";
			deliverableshtml += "</li>";
		}
		deliverableshtml += "</ol></td></tr></table>";
		deliverableshtml += "</tr>"; //end of process
	}
	deliverableshtml += "</table>";

	var deliverables = document.getElementById('deliverables');
	deliverables.innerHTML = deliverableshtml;

}

function drawDeliverable(id, json)
{
	var deliverableName = document.getElementById('deliverableName');
	deliverableName.innerHTML = "Deliverable: " + json.name;	
	
	var deliverableOwner = document.getElementById('deliverableOwner');
	if (json.owner)
		deliverableOwner.innerHTML = "Deliverable Owner: " + json.owner;
	
	var ownersArray = []
	for (var owner in json['process-owners'])
	{
		var program = "";
		if (json['process-owners'][owner].length > 0)
			program = " [" + json['process-owners'][owner] + "]";
		ownersArray.push(owner + program);
	}
	ownersArray.sort();
	if (ownersArray.length > 0)
	{
		var label = "Process Owner";
		var processOwner = document.getElementById('owners');
		if (ownersArray.length > 1)
			label += "s";
		processOwner.innerHTML = label + ": " + ownersArray.join(", ");	
	}	
	
	var deliverableDescription = document.getElementById('deliverableDescription');
	if (json.description)
		deliverableDescription.innerHTML = "Description: " + json.description;
		
	var deliverableFunction = document.getElementById('function');
	if (json['function'])
		deliverableFunction.innerHTML = "Function: " + json['function'];

	var deliverableNPI = document.getElementById('npi');
	var npi = "No"; //pessimist
	if (json.npi == 1) npi = "Yes";
		deliverableNPI.innerHTML = "New Product Introduction: " + npi;		
	
	var deliverableProcess = document.getElementById('deliverableProcess');
	deliverableProcess.innerHTML = "<span class='label label-default label-hover' onclick='window.location.href = \"./process.html?process=" + json.processid + "\"'>Process: " + json.process + "</span>";

	var deliverablePhase = document.getElementById('deliverablePhase');
	deliverablePhase.innerHTML = "<span class='label label-primary label-hover' onclick='window.location.href = \"./phase.html?phase=" + json.phaseid + "\"'>Phase: " + json.phase + "</span>";

	
	//draw in required by
	//var requiredbyhtml = "<li class='list-group-item groupheader'>Required By</li>";
	var requiredbyhtml = "";
	for (var i in json['required-by'])
	{
		var description = '';
		if (json['required-by'][i].description) 
			description = json['required-by'][i].description;	

		requiredbyhtml += "<li class='list-group-item'>";
		requiredbyhtml += "<a href='./deliverable.html?d=" + json['required-by'][i].id + "' title='" + description + "'>" + json['required-by'][i].name + "</a>";
		requiredbyhtml += "<p><span class='label label-default label-hover' onclick='window.location.href = \"./process.html?process=" + json['required-by'][i].processid + "\"'>Process: " + json['required-by'][i].process + "</span>";
		requiredbyhtml += " <span class='label label-primary label-hover' onclick='window.location.href = \"./phase.html?phase=" + json['required-by'][i].phaseid + "\"'>Phase: " + json['required-by'][i].phase + "</span></p>";
		requiredbyhtml += "</li>";
	}
	var requiredby = document.getElementById('requiredby');
	requiredby.innerHTML = requiredbyhtml;

	
	//draw in requires
	//var requireshtml = "<li class='list-group-item groupheader'>Requires</li>";
	var requireshtml = "";
	for (var i in json['requires'])
	{
		var description = '';
		if (json['requires'][i].description) 
			description = json['requires'][i].description;	
	
		requireshtml += "<li class='list-group-item'>";
		requireshtml += "<a href='./deliverable.html?d=" + json['requires'][i].id + "' title='" + description + "'>" + json['requires'][i].name + "</a>";
		requireshtml += "<p><span class='label label-default label-hover' onclick='window.location.href = \"./process.html?process=" + json['requires'][i].processid + "\"'>Process: " + json['requires'][i].process + "</span>";
		requireshtml += " <span class='label label-primary label-hover' onclick='window.location.href = \"./phase.html?phase=" + json['requires'][i].phaseid + "\"'>Phase: " + json['requires'][i].phase + "</span></p>";
		requireshtml += "</li>";
	}
	var requires = document.getElementById('requires');
	requires.innerHTML = requireshtml;	
	
}

function highlight(phaseID, processID)
{
	var processElement = document.getElementById('process' + processID);
	processElement.className = "processHeaderHighlight";
	
	if (phaseID != 0)
	{
		var phaseElement = document.getElementById('phase' + phaseID);
		phaseElement.className = "phaseHeaderHighlight";	
	}
	
	var processOwnerElement = document.getElementById('owner' + processID);
	if (processOwnerElement)
		processOwnerElement.className = "ownerHighlight";
}

function dehighlight(phaseID, processID)
{
	var processElement = document.getElementById('process' + processID);
	processElement.className = "processHeader";	
	
	if (phaseID != 0)
	{	
		var phaseElement = document.getElementById('phase' + phaseID);
		phaseElement.className = "phaseHeader";
	}
	
	var processOwnerElement = document.getElementById('owner' + processID);
	if (processOwnerElement)
		processOwnerElement.className = "owner";	
}

//taken off of stackoverflow
function getParameterByName(name) 
{
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}