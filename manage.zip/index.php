
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">

    <title>BBAR</title>

    <!-- Bootstrap core CSS -->
    <link href="includes/styles.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>

  <body>

	<?php include('navbar.php'); ?>

    <div class="container">

		<!-- Main component for a primary marketing message or call to action -->
		<!--<div class="jumbotron">
			<h1>First Time User</h1>
			<p>This area will be used for the first time people arrive at this page.</p>
			<p>It presently doesnt work, but will eventually.</p>
			<p>
			  <a class="btn btn-lg btn-primary" href="../../components/#navbar" role="button">View navbar docs &raquo;</a>
			</p>
		</div>-->
		
		<div class="alert alert-dismissable alert-warning">
			<button type="button" class="close" data-dismiss="alert">&times;</button>
			<h4>Warning!</h4>
			<p>All necessary approvals for this month have not yet been received.</p>
		</div>
		
		<h2 class="text-center" >Carrier SLA Report Approval</h2>

		<h3>October 2014  <span class="label label-danger">Not Approved</span></h3>
				
		<ul class="pager">
			<li class="previous"><a href="#">&larr; Older</a></li>
			<li class="next disabled"><a href="#">Newer &rarr;</a></li>
		</ul>
		
		<div class="bs-component">
			<table class="table table-striped table-hover ">
                <thead>
                  <tr>
                    <th>Resource</th>
                    <th>Data</th>
                    <th>Approve</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <!--<tr>
                    <td>1</td>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr class="info">
                    <td>3</td>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr class="success">
                    <td>4</td>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr class="danger">
                    <td>5</td>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr class="warning">
                    <td>6</td>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr class="active">
                    <td>7</td>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>-->
				  
					<tr>
						<td>Relay</td>
						<td>
							<a href="#" class="btn btn-xs btn-primary">Review Data</a>
						</td>
						<td>
						 <a href="#?svc=Relay&reg=AP" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#regionModal">AP</a> <a href="#" class="btn btn-xs btn-success" data-toggle="modal" data-target="#regionModal">EU</a> <a href="#" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#regionModal">NA</a>
						</td>
						<td>
							<span class="label label-danger">Not Approved</span>
						</td>
					</tr>
					<tr>
						<td>BISE</td>
						<td>
							<a href="#" class="btn btn-xs btn-primary">Review Data</a>
						</td>
						<td>
						 <a href="#?svc=BISE&reg=AP" class="btn btn-xs btn-success" data-toggle="modal" data-target="#regionModal">AP</a> <a href="#" class="btn btn-xs btn-success" data-toggle="modal" data-target="#regionModal">EU</a> <a href="#" class="btn btn-xs btn-success" data-toggle="modal" data-target="#regionModal">NA</a>
						</td>
						<td>
							<span class="label label-success">Approved</span>
						</td>
					</tr>					
					<tr>
						<td>PRV</td>
						<td>
							<a href="#" class="btn btn-xs btn-primary">Review Data</a>
						</td>
						<td>
						 <a href="#?svc=PRV&reg=AP" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#regionModal">AP</a> <a href="#" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#regionModal">EU</a> <a href="#" class="btn btn-xs btn-success" data-toggle="modal" data-target="#regionModal">NA</a>
						</td>
						<td>
							<span class="label label-danger">Not Approved</span>
						</td>
					</tr>
					<tr>
						<td>BBM</td>
						<td>
							<a href="#" class="btn btn-xs btn-primary">Review Data</a>
						</td>
						<td>
						 <a href="#?svc=BBM&reg=AP" class="btn btn-xs btn-success" data-toggle="modal" data-target="#regionModal">AP</a> <a href="#" class="btn btn-xs btn-success" data-toggle="modal" data-target="#regionModal">EU</a> <a href="#" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#regionModal">NA</a>
						</td>
						<td>
							<span class="label label-danger">Not Approved</span>
						</td>
					</tr>
					<tr>
						<td>BISB</td>
						<td>
							<a href="#" class="btn btn-xs btn-primary">Review Data</a>
						</td>
						<td>
						 <a href="#?svc=BISB&reg=AP" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#regionModal">AP</a> <a href="#" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#regionModal">EU</a> <a href="#" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#regionModal">NA</a>
						</td>
						<td>
							<span class="label label-danger">Not Approved</span>
						</td>
					</tr>
                </tbody>
              </table> 
            </div><!-- /example -->

    </div> <!-- /container -->

	 <div class="modal fade" id="regionModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title" id="modalLabel">Region Modal</h4>
          </div>
          <div class="modal-body">
			<h3>Who Is Approving?</h3>
			<div class="btn-group" data-toggle="buttons">
			  <label class="btn btn-primary active">
				<input type="radio" name="options" id="option1" autocomplete="off" checked> SM
			  </label>
			  <label class="btn btn-primary">
				<input type="radio" name="options" id="option2" autocomplete="off"> CSM
			  </label>
			</div>
			<input type="hidden" name="svcname" id="svcid">
			<input type="hidden" name="regname" id="regid">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            <button type="button" class="btn btn-success">Approve</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="includes/jquery-2.0.3.min.js"></script>
    <script src="includes/bootstrap.min.js"></script>
	<script>
		$('#basicModal').on('hidden.bs.modal', function (e) {
			//var value = $('#nameid').val();
			//alert(value);
		})

		$('#basicModal').on('show.bs.modal', function (e) {

		})

		$('a').bind('click',function(){
			var url = ($(this).attr('href'));
			var svc = getURLParameter(url, 'svc');
			var reg = getURLParameter(url, 'reg');
			//alert(url);
			//alert('svc: ' + svc + ' reg: ' + reg);
			var finalLabel = "Approve " + svc + " in " + reg;
			$('#svcid').val(svc);
			$('#regid').val(reg);
			$('#modalLabel').html(finalLabel);
		});
		function getURLParameter(url, name) {
			return (RegExp(name + '=' + '(.+?)(&|$)').exec(url)||[,null])[1];
		}
	</script>
  </body>
</html>
